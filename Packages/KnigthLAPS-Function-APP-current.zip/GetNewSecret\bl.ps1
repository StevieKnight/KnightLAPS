$VaultsFile = "$($PSScriptRoot)\\..\\..\\local.vaults.json"
Get-Content $VaultsFile